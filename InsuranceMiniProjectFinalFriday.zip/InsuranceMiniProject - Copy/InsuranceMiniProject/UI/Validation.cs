﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    public class Validation
    {
        public static bool ValidateName(string name)
        {
            if (!string.IsNullOrWhiteSpace(name) && char.IsLetter(name[0]) && name.Length > 1)
            {
                return true;
            }
            else
            {
                Console.WriteLine();
                TextFormatter.Typewriter("Invalid Name.", ConsoleColor.DarkRed);

                Console.WriteLine();
                return false;
            }
        }
        public static bool ValidateEmail(string email)
        {
            
            string emailPattern = @"^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$";

            if (!string.IsNullOrWhiteSpace(email) && Regex.IsMatch(email, emailPattern))
            {
                return true;
            }
            else
            {
                
                Console.WriteLine();
                TextFormatter.Typewriter("Invalid Email Format.", ConsoleColor.DarkRed);
                Console.ResetColor();
                return false;
            }
        }

        public static bool ValidatePhone(string phoneNumber)
        {
            if (!string.IsNullOrWhiteSpace(phoneNumber) && phoneNumber.Length == 10 && long.TryParse(phoneNumber, out _))
            {
                return true;
            }
            else
            {
                Console.WriteLine();
                TextFormatter.Typewriter("Invalid Phone Number.", ConsoleColor.DarkRed);
                Console.WriteLine();
                return false;
            }
        }
        public static bool ValidatePassword(string password)
        {
            string passwordPattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=!]).{6,}$";
            if (!string.IsNullOrWhiteSpace(password) && Regex.IsMatch(password, passwordPattern))
            {
                return true;
            }
            else
            {
                Console.WriteLine();
                TextFormatter.Typewriter("Contains at least 1 lowercase letter.\r\nContains at least 1 uppercase letter.\r\nContains at least 1 numeric digit.\r\nContains at least 1 special character among '@', '#', '$', '%', '^', '&', '+', '=', '!'.\r\nShould be at least 6 characters long.", ConsoleColor.DarkRed);
                Console.WriteLine();
                return false;
            }
        }
        public static bool ValidateConfirmpassword(string password, string confirmPassword)
        {
            if (!string.IsNullOrWhiteSpace(password) && password == confirmPassword)
            {
                return true;
            }
            else
            {
                Console.WriteLine();
                TextFormatter.Typewriter("Password and confirm password does not match.", ConsoleColor.DarkRed);
                Console.WriteLine();
                return false;
            }
        }

        public static int ValidateNumeric(string number)
        {
            if (!string.IsNullOrWhiteSpace(number) && int.TryParse(number, out int value))
            {
                return value;
            }
            else
            {
                Console.WriteLine();
                TextFormatter.Typewriter("Invalid Input.", ConsoleColor.DarkRed);
                Console.WriteLine();
                return -1;
            }
        }
        public static bool ValidateString(string name)
        {
            if (!string.IsNullOrWhiteSpace(name) && char.IsLetter(name[0]) && name.Length > 3)
            {
                return true;
            }
            else
            {
                Console.WriteLine();
                TextFormatter.Typewriter("Invalid Input.", ConsoleColor.DarkRed);
               
                Console.WriteLine();
                return false;
            }
        }
    }
}