﻿
using InsuranceMiniProject.Services.DTOs;
using InsuranceMiniProject.Services.Interface;
using InsuranceMiniProject.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    public class AdminMenu
    {
        private static IUserService _userService;
        private static IAuditLogService _auditLogService;
       
        public AdminMenu(IUserService service, IAuditLogService auditLogService)
        {
                _userService = service;
            _auditLogService = auditLogService;
        }
        public static void ShowMenu(UserBusinessModel currentUser)
        {
            Console.Clear();
            Console.WriteLine();
            TextFormatter.CenterAlign("Welcome " +currentUser.FirstName, ConsoleColor.DarkYellow);
            Console.WriteLine();

            try
            {
                if (currentUser.IsApprovedByAdmin == 1)
                {
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.WriteLine("╔════════════════════════════════════════════════════════╗");
                    Console.WriteLine("║                    ADMIN MENU                          ║");
                    Console.WriteLine("╠════════════════════════════════════════════════════════╣");
                    Console.WriteLine("║  1   View new admin requests.                          ║");
                    Console.WriteLine("║  2   View new agent requests.                          ║");
                    Console.WriteLine("║  3   View Logs                                         ║");
                    Console.WriteLine("║  4   Logout                                            ║");
                    Console.WriteLine("║  5   Exit                                              ║");
                    Console.WriteLine("╚════════════════════════════════════════════════════════╝");
                    Console.ResetColor();
                    Console.WriteLine();
                    TextFormatter.Typewriter("Enter your choice: ", ConsoleColor.White, false);
                    string choice = Console.ReadLine();
                    if (!int.TryParse(choice, out int res) || res > 5 || res < 1)
                    {
                        TextFormatter.Typewriter("Invalid Choice", ConsoleColor.DarkRed);
                        Console.WriteLine();
                        Console.WriteLine("Press any key to continue . . .");

                        Console.ReadKey();
                        ShowMenu(currentUser);
                    }

                    switch (res)
                    {

                        case 1:
                            Console.WriteLine();

                            TextFormatter.Typewriter("NEW ADMIN REQUESTS", ConsoleColor.DarkYellow);

                            var unapprovedAdmins = _userService.GetUnapprovedAdmins();

                            if (unapprovedAdmins.Count == 0)
                            {
                                Console.WriteLine("No new admin requests.");
                            }
                            else
                            {
                                foreach (var user in unapprovedAdmins)
                                {
                                    Console.WriteLine($"{user.Username} - {user.FirstName} {user.LastName}");
                                }
                                Console.WriteLine();
                                Console.Write("Enter the username of the admin you want to manage:");
                                string Username = Console.ReadLine();


                                var selectedAdmin = unapprovedAdmins.FirstOrDefault(u => u.Username == Username);
                                if (selectedAdmin == null)
                                {
                                    Console.WriteLine();
                                    TextFormatter.Typewriter("User with the entered username does not exist in pending list.", ConsoleColor.DarkRed);
                                    Console.WriteLine();
                                    Console.WriteLine("Press any key to continue...");
                                    Console.ReadKey();
                                    ShowMenu(currentUser);
                                }
                                Console.WriteLine("Choose an action: ");

                                Console.WriteLine("┌───────────────────────────────────┐");
                                Console.WriteLine("│  1   Approve                      │");
                                Console.WriteLine("│  2   Reject                       │");
                                Console.WriteLine("│  3   Defer                        │");
                                Console.WriteLine("└───────────────────────────────────┘");
                                string actionchoice1 = Console.ReadLine();
                                if (!int.TryParse(actionchoice1, out int res1) || res1 > 3|| res < 1)
                                {
                                    TextFormatter.Typewriter("Invalid Choice", ConsoleColor.DarkRed);
                                    Console.WriteLine();
                                    Console.WriteLine("Press any key to continue . . .");

                                    Console.ReadKey();
                                    ShowMenu(currentUser);
                                }
                                switch (res1)
                                {
                                    case 1:
                                        _userService.ProcessUserRequest(Username, 1);
                                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Approve", "Approved User", true);
                                        Console.WriteLine("Approved");
                                        Console.WriteLine();
                                        Console.WriteLine("Press any key to continue...");
                                        Console.ReadKey();

                                        break;
                                    case 2:

                                        _userService.ProcessUserRequest(Username, -1);
                                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Rejected", "Rejcted User", true);
                                        Console.WriteLine("Rejected");
                                        break;
                                    case 3:
                                        Console.WriteLine("Request deferred for later action.");
                                        break;
                                    default:
                                        //Console.WriteLine("Invalid action choice. Please try again.");
                                        break;
                                }
                            }
                            ShowMenu(currentUser);
                            break;
                        case 2:
                            Console.WriteLine();
                            TextFormatter.Typewriter("NEW AGENT REQUESTS", ConsoleColor.DarkYellow);
                            var unapprovedAgents = _userService.GetUnapprovedAgents();

                            if (unapprovedAgents.Count == 0)
                            {
                                Console.WriteLine("No new agent requests.");
                            }
                            else
                            {
                                foreach (var user in unapprovedAgents)
                                {
                                    Console.WriteLine($"{user.Username} - {user.FirstName} {user.LastName}");
                                }
                                Console.WriteLine();

                                Console.Write("Enter the username of the admin you want to manage:");
                                string Username = Console.ReadLine();
                                var selectedAgent = unapprovedAgents.FirstOrDefault(u => u.Username == Username);
                                if (selectedAgent == null)
                                {
                                    Console.WriteLine();
                                    TextFormatter.Typewriter("User with the entered username does not exist in pending list.", ConsoleColor.DarkRed);
                                    Console.WriteLine();
                                    Console.WriteLine("Press any key to continue...");
                                    Console.ReadKey();
                                    ShowMenu(currentUser);
                                }


                                Console.WriteLine();
                                Console.ForegroundColor = ConsoleColor.DarkGray;
                                Console.WriteLine("┌───────────────────────────────────┐");
                                Console.WriteLine("│  1   Approve                      │");
                                Console.WriteLine("│  2   Reject                       │");
                                Console.WriteLine("│  3   Defer                        │");
                                Console.WriteLine("└───────────────────────────────────┘");
                                Console.ResetColor();
                                Console.WriteLine();
                                Console.Write("Choose an action: ");
                                string actionchoice2 = Console.ReadLine();
                                if (!int.TryParse(actionchoice2, out int res2) || res2 > 3 || res < 2)
                                {
                                    TextFormatter.Typewriter("Invalid Choice", ConsoleColor.DarkRed);
                                    Console.WriteLine();
                                    Console.WriteLine("Press any key to continue . . .");

                                    Console.ReadKey();
                                    ShowMenu(currentUser);
                                }
                                switch (res2)
                                {
                                    case 1:
                                        Console.WriteLine("Approve");
                                        _userService.ProcessUserRequest(Username, 1);
                                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Approve", "Approved User", true);

                                        break;
                                    case 2:
                                        Console.WriteLine("Reject");
                                        _userService.ProcessUserRequest(Username, -1);
                                        _auditLogService.AddAuditLog(currentUser.Id, DateTime.Now, "Reject", "Rejected User", true);
                                        break;
                                    case 3:
                                        // later
                                        break;
                                    default:
                                        Console.WriteLine("Invalid action choice. Please try again.");
                                        break;
                                }
                            }
                            ShowMenu(currentUser);
                            break;
                        case 3:
                            var auditLogList = _userService.GetAuditLogs();

                            foreach (var item in auditLogList)
                            {
                                Console.WriteLine(item.Timestamp + "|" + item.UserId);
                            }
                            break;
                        case 4:
                            return;
                            break;
                        case 5:
                            Environment.Exit(0);
                            break;
                        default:
                            //TextFormatter.Typewriter("Invalid Choice.", ConsoleColor.DarkRed);
                            break;

                    }
                }
                else if (currentUser.IsApprovedByAdmin == -1)
                {
                    TextFormatter.Typewriter("You request has been rejected.", ConsoleColor.Red);
                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
                else
                {
                    TextFormatter.Typewriter("Your request has been submitted successfully. Please wait for approval", ConsoleColor.DarkGreen);
                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
      
            catch(Exception ex)
            {
                Console.WriteLine();
                TextFormatter.Typewriter("An error occurred : " + ex.Message, ConsoleColor.DarkRed);
            }
            
            
        }


        
    }
}



