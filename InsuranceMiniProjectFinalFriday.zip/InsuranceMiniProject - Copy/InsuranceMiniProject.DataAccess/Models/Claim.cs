﻿using System;
using System.Collections.Generic;

namespace InsuranceMiniProject.DataAccess.Models;

public partial class Claim
{
    public int Id { get; set; }

    public int? PolicyId { get; set; }

    public int? UserId { get; set; }

    public int? AgentId { get; set; }

    public DateOnly? IncidentDate { get; set; }

    public string? Description { get; set; }

    public string? Status { get; set; }

    public virtual User? Agent { get; set; }

    public virtual Policy? Policy { get; set; }

    public virtual User? User { get; set; }
}
