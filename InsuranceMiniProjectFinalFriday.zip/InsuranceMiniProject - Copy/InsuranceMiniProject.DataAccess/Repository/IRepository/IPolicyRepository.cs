﻿using InsuranceMiniProject.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.DataAccess.Repository.IRepository
{
    public interface IPolicyRepository
    {
        List<Policy> GetAllPolicies();
        Policy GetPolicyByPolicyNumber(string policyNumber);
    }
}
