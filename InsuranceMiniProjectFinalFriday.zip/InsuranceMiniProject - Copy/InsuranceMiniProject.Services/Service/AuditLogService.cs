﻿using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.Services.Service
{
    public class AuditLogService : IAuditLogService
    {
        private readonly IAuditLogRepository _auditLogRepository;

        public AuditLogService(IAuditLogRepository auditLogRepository)
        {
            _auditLogRepository = auditLogRepository;
        }

        public void AddAuditLog(int userId, DateTime timestamp, string action, string details, bool isSuccess)
        {
            _auditLogRepository.AddAuditLog(userId, timestamp, action, details, isSuccess);
        }
    }
}
