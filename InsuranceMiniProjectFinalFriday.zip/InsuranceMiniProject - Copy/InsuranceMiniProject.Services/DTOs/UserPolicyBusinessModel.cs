﻿using InsuranceMiniProject.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.Services.DTOs
{
    public class UserPolicyBusinessModel
    {
        public int Id { get; set; }

        public int? UserId { get; set; }

        public int? PolicyId { get; set; }

        public int? AgentId { get; set; }

        public DateOnly? EnrollmentDate { get; set; }

        public DateOnly? EndDate { get; set; }

        public bool? IsActive { get; set; }

    }
}
