﻿using InsuranceMiniProject.DataAccess.BusinessModels;
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.Services.DTOs;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.Services.Interface
{
    public interface IUserService
    {
        void RegisterUser(string firstName, string lastName, string username, string password, string email, string phoneNumber, int roleId);
        UserBusinessModel GetUserByCredentials(string username, string password, int roleId);
        List<User> GetUnapprovedAdmins();
        List<User> GetUnapprovedAgents();
        List<User> GetApprovedAgents();
        void ProcessUserRequest(string username, int action);
        int BuyPolicy(UserPolicyBusinessModel userPolicy);

        List<UserPolicyWithUserBusinessModel> GetUserPolicies(int userId);
        List<UserPolicyWithUserBusinessModel> GetAgentPolicies(int userId);

        int AddClaim(int policyId, int userId, DateOnly incidentDate, string description, int agentId);

        public List<ClaimWithUserNameBusinessModel> GetClaimsForAgent(int agentId);
       
        List<AuditLog> GetAuditLogs();
        






    }
}
