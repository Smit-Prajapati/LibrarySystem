create database InsuranceDb;
use InsuranceDb;


-- Create Role table
CREATE TABLE Role (
    ID INT PRIMARY KEY IDENTITY,
    RoleName NVARCHAR(50) UNIQUE
);

-- Create Users table
CREATE TABLE Users (
    ID INT PRIMARY KEY IDENTITY,
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    Email NVARCHAR(100) UNIQUE,
    PhoneNumber NVARCHAR(20),
    RoleId INT,
    IsApprovedByAdmin INT DEFAULT 0, -- New column to track admin approval (0: Not approved, 1: Approved, -1: Rejected)
    IsActive BIT,
    FOREIGN KEY (RoleId) REFERENCES Role(ID)
);



-- Create Policies table
CREATE TABLE Policies (
    ID INT PRIMARY KEY IDENTITY,
    PolicyNumber NVARCHAR(50) NOT NULL UNIQUE,
	PolicyName Nvarchar(50) NOT NULL,
    CoverageType NVARCHAR(100),
    Duration INT,
    Description NVARCHAR(MAX),
    Installment DECIMAL(18,2),
    PremiumAmount DECIMAL(18,2),
    IsActive BIT
);

-- Create UserPolicy table
CREATE TABLE UserPolicy (
    ID INT PRIMARY KEY IDENTITY,
    UserId INT,
    PolicyId INT,
	AgentId INT,
    EnrollmentDate DATE,
    EndDate DATE,
    IsActive BIT,
    FOREIGN KEY (UserId) REFERENCES Users(ID),
	FOREIGN KEY (AgentId) REFERENCES Users(ID),
    FOREIGN KEY (PolicyId) REFERENCES Policies(ID),
    CONSTRAINT UC_UserPolicy UNIQUE (UserId, PolicyId)
);

-- Create Claims table
CREATE TABLE Claims (
    ID INT PRIMARY KEY IDENTITY,
    PolicyId INT,
    UserId INT,
    IncidentDate DATE,
    Description NVARCHAR(MAX),
    Status NVARCHAR(50),
    FOREIGN KEY (PolicyId) REFERENCES Policies(ID),
    FOREIGN KEY (UserId) REFERENCES Users(ID)
);

-- Create AuditLogs table
CREATE TABLE AuditLogs (
    ID INT PRIMARY KEY IDENTITY,
    UserId INT,
    Timestamp DATETIME,
    Action NVARCHAR(100) NOT NULL,
    Details NVARCHAR(MAX),
    IsSuccess BIT,
    FOREIGN KEY (UserId) REFERENCES Users(ID)
);

-- Create ClaimHistory table
CREATE TABLE ClaimHistory (
    ID INT PRIMARY KEY IDENTITY,
    ClaimId INT,
    Action VARCHAR(50),
    ActionDate DATETIME,
    ActionBy INT,
    FOREIGN KEY (ClaimId) REFERENCES Claims(ID),
    FOREIGN KEY (ActionBy) REFERENCES Users(ID)
);



INSERT INTO Role (RoleName) VALUES ('Admin');
INSERT INTO Role (RoleName) VALUES ('Agent');
INSERT INTO Role (RoleName) VALUES ('User');

-- Inserting an admin user
INSERT INTO Users (FirstName, LastName, Username, Password, Email, PhoneNumber, RoleId, IsApprovedByAdmin, IsActive)
VALUES ('Admin', 'User', 'admin', 'admin@123', 'admin0@gmail.com', '1234567890', 1, 1, 1);

INSERT INTO Policies (PolicyNumber, PolicyName, CoverageType, Duration, Description, Installment, PremiumAmount, IsActive)
VALUES 
    ('POL001', 'Health Insurance', 'Health Insurance', 365, 'Health insurance policy covering medical expenses', 100.00, 1200.00, 1),
    ('POL002', 'Life Insurance', 'Life Insurance', 730, 'Life insurance policy providing coverage for 2 years', 150.00, 3600.00, 1),
	('POL005', 'Travel Insurance', 'Travel Insurance', 365, 'Travel insurance policy covering trip cancellations and medical emergencies', 50.00, 50.00, 0),
    ('POL003', 'Car Insurance', 'Car Insurance', 183, 'Car insurance policy covering damages and liabilities', 75.00, 450.00, 1),
    ('POL004', 'Home Insurance', 'Home Insurance', 1825, 'Home insurance policy protecting against property damage', 200.00, 7200.00, 1),
    ('POL006', 'Pet Insurance', 'Pet Insurance', 365, 'Pet insurance policy covering veterinary expenses', 80.00, 960.00, 0);


	-- Insert 5 users
INSERT INTO Users (FirstName, LastName, Username, Password, Email, PhoneNumber, RoleId, IsActive)
VALUES
    ('John', 'Doe', 'user1', 'user1password', 'john.doe@example.com', '1234567890', 1, 0),
    ('Jane', 'Smith', 'user2', 'user2password', 'jane.smith@example.com', '1234567890', 1, 0),
    ('Michael', 'Johnson', 'user3', 'user3password', 'michael.johnson@example.com', '1234567890', 1, 0),
    ('Emily', 'Brown', 'user4', 'user4password', 'emily.brown@example.com', '1234567890', 1, 0),
    ('William', 'Wilson', 'user5', 'user5password', 'william.wilson@example.com', '1234567890', 1, 0);

-- Insert 5 agents
INSERT INTO Users (FirstName, LastName, Username, Password, Email, PhoneNumber, RoleId, IsActive)
VALUES

    ('Sophia', 'Anderson', 'agent2', 'agent2password', 'sophia.anderson@example.com', '1234567890', 2, 0),
    ('Emma', 'Garcia', 'agent3', 'agent3password', 'emma.garcia@example.com', '1234567890', 2, 0),
    ('James', 'Lopez', 'agent4', 'agent4password', 'james.lopez@example.com', '1234567890', 2, 0),
    ('Olivia', 'Thomas', 'agent5', 'agent5password', 'olivia.thomas@example.com', '1234567890', 2, 0);

-- Insert 5 admins
INSERT INTO Users (FirstName, LastName, Username, Password, Email, PhoneNumber, RoleId, IsActive)
VALUES
    ('Admin', 'Three', 'admin3', 'admin3password', 'admin3@example.com', '1234567890', 3, 0),
    ('Admin', 'Four', 'admin4', 'admin4password', 'admin4@example.com', '1234567890', 3, 0),
    ('Admin', 'Five', 'admin5', 'admin5password', 'admin5@example.com', '1234567890', 3, 0);

	-- Insert 5 new agents

	INSERT INTO Users (FirstName, LastName, Username, Password, Email, PhoneNumber, RoleId, IsActive, IsApprovedByAdmin)
VALUES
    ('Ella', 'Moore', 'agent6', 'agent6password', 'ella.moore@example.com', '1234567890', 2, 0, 1),
    ('Aiden', 'Parker', 'agent7', 'agent7password', 'aiden.parker@example.com', '1234567890', 2, 0, 1),
    ('Ava', 'Rivera', 'agent8', 'agent8password', 'ava.rivera@example.com', '1234567890', 2, 0, 1),
    ('Liam', 'Harris', 'agent9', 'agent9password', 'liam.harris@example.com', '1234567890', 2, 0, 1),
    ('Mia', 'Cooper', 'agent10', 'agent10password', 'mia.cooper@example.com', '1234567890', 2, 0, 1);


select * from Policies;
select * from users;
select * from userPolicy;
select * from AuditLogs;
select * from Claims;




--delete from Policies;
--DBCC CHECKIDENT ('Policies', RESEED, 0);

delete from Users 
where firstname = '';

SET IDENTITY_INSERT Users ON;
INSERT INTO Users (ID, FirstName, LastName, Username, Password, Email, PhoneNumber, RoleId, IsApprovedByAdmin, IsActive)
VALUES (-1, 'Guest', 'User', 'guest', 'guestpassword', 'guest@example.com', '1234567890', 3, 1, 1);
SET IDENTITY_INSERT Users OFF;




select * from UserPolicy 
where AgentId = 28;

SELECT up.ID AS UserPolicyID,
       up.UserId,
       up.PolicyId,
       up.AgentId,
       up.EnrollmentDate AS PolicyStartDate,
       up.EndDate AS PolicyEndDate,
       u.FirstName + ' ' + u.LastName AS UserName,
       p.PolicyName,
       p.CoverageType,
       p.Description,
       a.FirstName + ' ' + a.LastName AS AgentName
FROM UserPolicy up
JOIN Users u ON up.UserId = u.ID
JOIN Policies p ON up.PolicyId = p.ID
JOIN Users a ON up.AgentId = a.ID
WHERE up.AgentId = 28;