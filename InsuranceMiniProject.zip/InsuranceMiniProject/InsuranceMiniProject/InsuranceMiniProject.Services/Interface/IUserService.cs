﻿using InsuranceMiniProject.DataAccess.BusinessModels;
using InsuranceMiniProject.DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.Services.Interface
{
    public interface IUserService
    {
        void RegisterUser(string firstName, string lastName, string username, string password, string email, string phoneNumber, int roleId);
        User GetUserByCredentials(string username, string password, int roleId);
        List<User> GetUnapprovedAdmins();
        List<User> GetUnapprovedAgents();
        List<User> GetApprovedAgents();
        void ProcessUserRequest(string username, int action);
        void BuyPolicy(UserPolicy userPolicy);

        List<UserPolicyServiceModel> GetUserPolicies(int userId);
        List<UserPolicyServiceModel> GetAgentPolicies(int userId);

        void AddClaim(int policyId, int userId, DateOnly incidentDate, string description);
        






    }
}
