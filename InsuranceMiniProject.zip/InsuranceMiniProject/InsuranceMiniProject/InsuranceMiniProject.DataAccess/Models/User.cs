﻿using System;
using System.Collections.Generic;

namespace InsuranceMiniProject.DataAccess.Models;

public partial class User
{
    public int Id { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string Username { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string? Email { get; set; }

    public string? PhoneNumber { get; set; }

    public int? RoleId { get; set; }

    public int? IsApprovedByAdmin { get; set; }

    public bool? IsActive { get; set; }

    public virtual ICollection<AuditLog> AuditLogs { get; set; } = new List<AuditLog>();

    public virtual ICollection<ClaimHistory> ClaimHistories { get; set; } = new List<ClaimHistory>();

    public virtual ICollection<Claim> Claims { get; set; } = new List<Claim>();

    public virtual Role? Role { get; set; }

    public virtual ICollection<UserPolicy> UserPolicyAgents { get; set; } = new List<UserPolicy>();

    public virtual ICollection<UserPolicy> UserPolicyUsers { get; set; } = new List<UserPolicy>();
}
