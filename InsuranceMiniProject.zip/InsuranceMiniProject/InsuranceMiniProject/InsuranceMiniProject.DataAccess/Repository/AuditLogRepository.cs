﻿using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.DataAccess.Repository
{
    public class AuditLogRepository : IAuditLogRepository
    {
        private readonly InsuranceDbContext _dbContext;

        public AuditLogRepository(InsuranceDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AddAuditLog(int userId, DateTime timestamp, string action, string details, bool isSuccess)
        {
            try
            {
                var auditLog = new AuditLog
                {
                    UserId = userId,
                    Timestamp = timestamp,
                    Action = action,
                    Details = details,
                    IsSuccess = isSuccess
                };

                _dbContext.AuditLogs.Add(auditLog);
                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while adding the audit log: {ex.Message}");
                
            }
        }

    }
}


