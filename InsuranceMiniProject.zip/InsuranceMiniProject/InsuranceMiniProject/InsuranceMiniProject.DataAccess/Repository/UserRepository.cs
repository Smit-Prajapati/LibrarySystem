﻿using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.DataAccess;
using InsuranceMiniProject.DataAccess.Repository.IRepository;
using InsuranceMiniProject.DataAccess.Enum;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using InsuranceMiniProject.DataAccess.BusinessModels;
using Microsoft.Extensions.Logging;

namespace InsuranceMiniProject.DataAccess.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly InsuranceDbContext _dbContext;

        public UserRepository(InsuranceDbContext context)
        {
            _dbContext = context;
        }

        public int AddUser(User newUser)
        {
            if(_dbContext.Users.Any(u => u.Username == newUser.Username)) {
                Console.WriteLine("User name is not available");
                return 0;
            }
            if (_dbContext.Users.Any(u => u.Email == newUser.Email)) {
                Console.WriteLine("Email is already exists");
                return 0;
            }

            _dbContext.Users.Add(newUser);
            return _dbContext.SaveChanges();
            
        }

        public User GetUserByCredentials(string username, string password, int roleId)
        {
            var user = _dbContext.Users
                .FirstOrDefault(u => u.Username == username && u.Password == password && u.RoleId == roleId);

            return user;
        }


        public List<User> GetUnapprovedAdmins()
        {
            return _dbContext.Users
                .Where(u => u.RoleId == (int)RoleEnum.Admin && u.IsApprovedByAdmin == 0)
                .ToList();
        }

        public List<User> GetUnapprovedAgents()
        {
            return _dbContext.Users
                .Where(u => u.RoleId == (int)RoleEnum.Agent && u.IsApprovedByAdmin == 0)
                .ToList();
        }
        public List<User> GetApprovedAgents()
        {
            return _dbContext.Users
                .Where(u => u.RoleId == (int)RoleEnum.Agent && u.IsApprovedByAdmin == 1)
                .ToList();
        }

        public void ProcessUserRequest(string username, int action)
        {
            var admin = _dbContext.Users.FirstOrDefault(u => u.Username == username);
            if (admin != null)
            {
                admin.IsApprovedByAdmin = action; 
                _dbContext.SaveChanges(); 
            }
        }

        public void AddUserPolicy(UserPolicy userPolicy)
        {
            try
            {
                _dbContext.UserPolicies.Add(userPolicy);
                _dbContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                var sqlException = ex.GetBaseException() as SqlException;
                if (sqlException != null && sqlException.Number == 2601) 
                {
                   
                    Console.WriteLine("You have already bought this policy.");
                }
                else
                {
                    
                    Console.WriteLine("An error occurred while adding the user policy.");
                }
            }
        }

        public List<UserPolicyServiceModel> GetUserPolicies(int userId)
        {
            var userPolicyInfo = (from up in _dbContext.UserPolicies
                                  join p in _dbContext.Policies on up.PolicyId equals p.Id
                                  join a in _dbContext.Users on up.AgentId equals a.Id
                                  where up.UserId == userId
                                  select new UserPolicyServiceModel
                                  {
                                      PolicyName = p.PolicyName,
                                      CoverageType = p.CoverageType,
                                      Description = p.Description,
                                      PolicyStartDate = (DateOnly)up.EnrollmentDate,
                                      PolicyEndDate = (DateOnly)up.EndDate,
                                      AgentName = $"{a.FirstName} {a.LastName}"
                                  }).ToList();

            return userPolicyInfo;
        }

        public List<UserPolicyServiceModel> GetAgentPolicies(int agentId)
        {
            var agentPolicies = (from up in _dbContext.UserPolicies
                     join u in _dbContext.Users on up.UserId equals u.Id
                     join p in _dbContext.Policies on up.PolicyId equals p.Id
                     join a in _dbContext.Users on up.AgentId equals a.Id
                     where up.AgentId == agentId
                     select new UserPolicyServiceModel
                     {
                         PolicyName = p.PolicyName,
                         PolicyNumber = p.PolicyNumber,
                         CoverageType = p.CoverageType,
                         Description = p.Description,
                         PolicyStartDate = up.EnrollmentDate,
                         PolicyEndDate = up.EndDate,
                         AgentName = a.FirstName + " " + a.LastName,
                         UserName = u.FirstName + " " + u.LastName
                     }).ToList();
            return agentPolicies;

        }

       

        

        public void AddClaim(int policyId, int userId, DateOnly incidentDate, string description)
        {
            var claim = new Claim
            {
                PolicyId = policyId,
                UserId = userId,
                IncidentDate = incidentDate,
                Description = description,
                Status = "Pending"
            };

            _dbContext.Claims.Add(claim);
            _dbContext.SaveChanges();
        }

        
    }
}

