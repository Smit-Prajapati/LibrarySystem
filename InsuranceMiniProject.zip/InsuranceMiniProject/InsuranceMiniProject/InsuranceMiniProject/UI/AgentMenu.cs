﻿using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.Services.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    
    public class AgentMenu
    {
        private static IPolicyService _policyService;
        private static IUserService _userService;
        public AgentMenu(IPolicyService service, IUserService userService)
        {
            _policyService = service;
            _userService = userService;
        }
        public static void ShowMenu(User currentUser)
        {
            Console.Clear();
            Console.WriteLine();
            TextFormatter.CenterAlign("Welcome " + currentUser.FirstName, ConsoleColor.DarkYellow);
            Console.WriteLine();

            try
            {
                if (currentUser.IsApprovedByAdmin == 1)
                {
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.WriteLine("╔════════════════════════════════════════════════════════╗");
                    Console.WriteLine("║                     AGENT MENU                         ║");
                    Console.WriteLine("╠════════════════════════════════════════════════════════╣");
                    Console.WriteLine("║  1   View assigned Policies                            ║");
                    Console.WriteLine("║  2   View all policies                                 ║");
                    Console.WriteLine("║  3   View Claims                                       ║");
                    Console.WriteLine("║  4   View Claims history                               ║");
                    Console.WriteLine("║  5   Logout                                            ║");
                    Console.WriteLine("║  6   Exit                                              ║");
                    Console.WriteLine("╚════════════════════════════════════════════════════════╝");
                    Console.ResetColor();
                    Console.WriteLine();
                    Console.WriteLine("\nEnter your choice: ");
                    string choice = Console.ReadLine();
                    if (!int.TryParse(choice, out int res) || res > 6 || res < 1)
                    {
                        TextFormatter.Typewriter("Invalid Choice", ConsoleColor.DarkRed);
                        Console.WriteLine();
                        Console.WriteLine("Press any key to continue . . .");

                        Console.ReadKey();
                        ShowMenu(currentUser);
                    }

                    switch (res)
                    {
                        case 1:
                            var agentPolicies = _userService.GetAgentPolicies(currentUser.Id);
                            foreach (var policy in agentPolicies)
                            {
                                Console.WriteLine($"{policy.UserName} | {policy.PolicyNumber} | {policy.PolicyName}");
                            }

                            break;
                        case 2:
                            var policies = _policyService.GetAllPolicies();
                            Console.WriteLine("\nAll Policies:");
                            foreach (var policy in policies)
                            {
                                Console.WriteLine($"ID: {policy.Id}");
                                Console.WriteLine($"Policy Number: {policy.PolicyNumber}");
                                Console.WriteLine($"Coverage Type: {policy.CoverageType}");
                                Console.WriteLine($"Duration: {policy.Duration} months");
                                Console.WriteLine($"Description: {policy.Description}");
                                Console.WriteLine($"Installment: {policy.Installment}");
                                Console.WriteLine($"Premium Amount: {policy.PremiumAmount}");

                                Console.WriteLine();
                            }
                            break;
                        case 3:
                            TextFormatter.CenterAlign("Submitted Claims", ConsoleColor.DarkYellow);
                            break;
                        case 4:
                            TextFormatter.CenterAlign("Submitted Claims", ConsoleColor.DarkYellow);
                            break;
                        case 5:
                            return;
                            break;
                        case 6:
                            Environment.Exit(0);
                            break;
                        default:
                            //Console.WriteLine("Invalid Choice");
                            break;

                    }
                }
                else if (currentUser.IsApprovedByAdmin == -1)
                {
                    TextFormatter.Typewriter("You request has been rejected.", ConsoleColor.Red);
                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
                else
                {
                    TextFormatter.Typewriter("Your request has been submitted successfully. Please wait for approval", ConsoleColor.DarkGreen);
                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                TextFormatter.Typewriter("An error occurred : " + ex.Message);
            }
        }
    }
}
