﻿using InsuranceMiniProject.DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.DataAccess.Repository.IRepository
{
    public interface IUserRepository
    {
        void AddUser(User newUser);
        //bool ValidateUserCredentials(string username, string password, int roleId);
        User GetUserByCredentials(string username, string password, int roleId);
       

        List<User> GetUnapprovedAdmins();

        List<User> GetUnapprovedAgents();

        void ProcessUserRequest(string username, int action);
        void AddUserPolicy(UserPolicy userPolicy);
    }
}
