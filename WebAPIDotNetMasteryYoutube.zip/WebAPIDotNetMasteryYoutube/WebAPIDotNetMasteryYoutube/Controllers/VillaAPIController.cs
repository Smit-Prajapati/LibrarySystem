﻿using Microsoft.AspNetCore.Mvc;
using WebAPIDotNetMasteryYoutube.Data;
using WebAPIDotNetMasteryYoutube.Models;
using WebAPIDotNetMasteryYoutube.Models.DTO;

namespace WebAPIDotNetMasteryYoutube.Controllers
{
    [Route("api/VillaAPI")]
    [ApiController]

    public class VillaAPIController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public VillaAPIController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)] //success
        public ActionResult<IEnumerable<VillaDTO>> GetVillas()
        {
            return Ok(_context.Villas.ToList());
        }




        [HttpGet("{id:int}", Name ="GetVilla")] //or [HttpGet("id")]
        //[ProducesResponseType(200)] //success
        [ProducesResponseType(StatusCodes.Status200OK)] //success
        [ProducesResponseType(StatusCodes.Status400BadRequest)] //bad request
        [ProducesResponseType(StatusCodes.Status404NotFound)] //not found
        public ActionResult<VillaDTO> GetVilla(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }

            var villa = _context.Villas.FirstOrDefault(u => u.Id == id);
            if (villa == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(villa);
            }
        }




        [HttpPost]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        //[ProducesResponseType(StatusCodes.Status200OK)] //after returning createdAtRount we'll get 201 instead of 200
        public ActionResult<VillaDTO> CreateVilla([FromBody]VillaDTO villaDTO)
        {
            //if (!ModelState.IsValid) //instead of this we can add [apicontroller]. it will check annotations in dto model.
            //{
            //    return BadRequest(ModelState);
            //}

            if (_context.Villas.FirstOrDefault(u=>u.Name.ToLower() == villaDTO.Name.ToLower()) != null)
            {
                ModelState.AddModelError("Custome Error", "Villa already exists."); 
                return BadRequest(ModelState);
            }
            if(villaDTO == null)
            {
                return BadRequest(villaDTO);
            }
            if(villaDTO.Id > 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

            Villa model = new Villa
            {
                Amenity = villaDTO.Amenity,
                Details = villaDTO.Details,
                ImageUrl = villaDTO.ImageUrl,
                Name = villaDTO.Name,
                Occupancy = villaDTO.Occupancy,
                Sqft = villaDTO.Sqft,
                Rate = villaDTO.Rate,
            };
            _context.Villas.Add(model);
            _context.SaveChanges();

            int newVillaId = model.Id;

            //return Ok(villaDTO);//instead of returning objec we can return endpoint where this data is added
            // Return the location URL with the correct ID
            return CreatedAtRoute("GetVilla", new { id = newVillaId }, villaDTO);//first is route name


        }



        [HttpDelete("{id:int}", Name = "DeleteVilla")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public IActionResult DeleteVilla(int id)
        {
            if(id == 0)
            {
                return BadRequest();
            }

            var villa = _context.Villas.FirstOrDefault(u => u.Id == id);
            if(villa  == null)
            {
                return NotFound();
            }

            _context.Villas.Remove(villa);
            _context.SaveChanges();

            return NoContent();
        }


        [HttpPut("{id:int}", Name = "UpdateVilla")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult UpdateVilla(int id, [FromBody]VillaDTO villaDTO)
        {
            if(villaDTO == null || id != villaDTO.Id)
            {
                return BadRequest();
            }

            var villa = _context.Villas.FirstOrDefault(u=>u.Id == id);

            Villa model = new()
            {
                Amenity = villaDTO.Amenity,
                Details = villaDTO.Details,
                ImageUrl = villaDTO.ImageUrl,
                Name = villaDTO.Name,
                Occupancy = villaDTO.Occupancy,
                Sqft = villaDTO.Sqft,
                Rate = villaDTO.Rate,
                Id = villaDTO.Id,
            };
            _context.Update(model);
            return NoContent();

        }




    }
}
