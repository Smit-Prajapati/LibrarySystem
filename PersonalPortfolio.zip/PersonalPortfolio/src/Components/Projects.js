import { useState } from "react";
import { Typography, Button, Grid, Paper, Container } from "@mui/material";
import Masonry from "@mui/lab/Masonry";
import SectionTitle from "./SectionTitle";

const imageData = [
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd1.jpg",
    alt: "Image 1",
    category: "uiDesign",
  },
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd2.jpg",
    alt: "Image 2",
    category: "uiDesign",
  },
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd3.jpg",
    alt: "Image 3",
    category: "uiDesign",
  },
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd4.jpg",
    alt: "Image 3",
    category: "uiDesign",
  },
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd5.jpg",
    alt: "Image 3",
    category: "uiDesign",
  },
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd1.jpg",
    alt: "Image 1",
    category: "uiDesign",
  },
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd2.jpg",
    alt: "Image 2",
    category: "uiDesign",
  },
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd4.jpg",
    alt: "Image 3",
    category: "uiDesign",
  },
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd5.jpg",
    alt: "Image 3",
    category: "uiDesign",
  },
  {
    src: "https://smit-prajapati.github.io/prajapatismit/images/xd3.jpg",
    alt: "Image 3",
    category: "uiDesign",
  },
  { src: "image4.jpg", alt: "Image 4", category: "photoshop" },
  { src: "image4.jpg", alt: "Image 4", category: "photoshop" },
  { src: "image5.jpg", alt: "Image 5", category: "webDevelopment" },
  { src: "image6.jpg", alt: "Image 6", category: "webDevelopment" },
  { src: "image6.jpg", alt: "Image 6", category: "webDevelopment" },
];

const ProjectsSection = () => {
  const [selectedCategory, setSelectedCategory] = useState("uiDesign");

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
  };

  const filteredImages = imageData.filter(
    (image) => image.category === selectedCategory
  );

  return (
    <Container maxWidth="lg">
      <SectionTitle title={"MY PROJECTS"} />
      <Grid
        container
        spacing={2}
        justifyContent="center"
        sx={{ marginTop: "2rem", marginBottom: "2rem" }}
      >
        <Grid item>
          <Button
            variant={selectedCategory === "uiDesign" ? "contained" : "outlined"}
            onClick={() => handleCategoryChange("uiDesign")}
            sx={{
              color: selectedCategory === "uiDesign" ? "white" : "primary",
            }}
          >
            UI Design
          </Button>
        </Grid>
        <Grid item>
          <Button
            variant={
              selectedCategory === "photoshop" ? "contained" : "outlined"
            }
            onClick={() => handleCategoryChange("photoshop")}
            sx={{
              color: selectedCategory === "photoshop" ? "white" : "primary",
            }}
          >
            Photoshop
          </Button>
        </Grid>
        <Grid item>
          <Button
            variant={
              selectedCategory === "webDevelopment" ? "contained" : "outlined"
            }
            onClick={() => handleCategoryChange("webDevelopment")}
            sx={{
              color:
                selectedCategory === "webDevelopment" ? "white" : "primary",
            }}
          >
            Web Development
          </Button>
        </Grid>
      </Grid>

      {/* Masonry grid */}
      <Masonry columns={3} spacing={2}>
        {filteredImages.map((image, index) => (
          <Paper key={index}>
            <a href={image.src} target="_blank" rel="noopener noreferrer">
              <img
                src={image.src}
                alt={image.alt}
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            </a>
          </Paper>
        ))}
      </Masonry>
    </Container>
  );
};

export default ProjectsSection;
