import { Grid, Paper, Container, Typography } from "@mui/material";
import ReactLogo from "../assets/images/react-logo.png";
import CSharpLogo from "../assets/images/csharp-logo.png";
import SqlLogo from "../assets/images/sql-logo.png";
import SassLogo from "../assets/images/sass-logo.png";
import XdLogo from "../assets/images/xd-logo.png";
import PhotoshopLogo from "../assets/images/photoshop-logo.png";
import IllustratorLogo from "../assets/images/Illustrator-logo.png";
import BlenderLogo from "../assets/images/blender-logo.png";
import SectionTitle from "./SectionTitle";

const logos = [
  { src: ReactLogo, alt: "React", name: "React" },
  { src: CSharpLogo, alt: "CSharp", name: "CSharp" },
  { src: SqlLogo, alt: "sql", name: "Sql" },
  { src: SassLogo, alt: "sass", name: "Sass" },
  { src: XdLogo, alt: "xd", name: "XD" },
  { src: PhotoshopLogo, alt: "photoshop", name: "Photoshop" },
  { src: IllustratorLogo, alt: "illustrator", name: "Illustrator" },
  { src: BlenderLogo, alt: "blender", name: "Blender" },
];
const Skills = () => {
  return (
    <Container maxWidth="lg">
      <SectionTitle title={"SKILLS"} />
      <Grid container spacing={5} sx={{ marginTop: "1rem" }}>
        {logos.map((logo, index) => (
          <Grid
            item
            xs={6}
            sm={2}
            key={index}
            sx={{ justifyContent: "center" }}
          >
            <Paper
              sx={{
                backgroundColor: "white",
                padding: 5,
                boxShadow: "rgba(100, 100, 111, 0.2) 0px 7px 29px 0px",
                aspectRatio: "1",
                
              }}
            >
              <img
                src={logo.src}
                alt={logo.alt}
                style={{ width: "100%", height: "100%", objectFit: "contain" }}
              />
              <Typography color={"#333"} sx={{ textAlign: "center", fontWeight:"800" }}>
                {logo.name}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Skills;
