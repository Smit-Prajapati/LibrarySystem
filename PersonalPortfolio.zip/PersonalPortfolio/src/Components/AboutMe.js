import React from "react";
import { Typography, Grid, Container } from "@mui/material";
import aboutMeImage from "../assets/images/about-me.png";
import SectionTitle from "./SectionTitle";

const AboutMe = () => {
  return (
    <div style={{ padding: " 0" }}>
        
      <Container maxWidth="lg">
        <SectionTitle title = {"ABOUT SMIT"}/>
        <Grid container sx={{ display: 'flex', gap: '10rem', alignItems: 'center', flexWrap: { xs: 'wrap', sm: 'nowrap' } }}>
          <Grid item xs={12} sm={6} sx={{paddingtop:{xs:"2rem"}}}>
            <Typography
              variant="h6"
              gutterBottom
              sx={{ fontWeight: "500", color: "gray" }}
            >
              An ambitious Full-stack Developer and designer who takes great pride in the presentation and quality of work.
              <br/>
              Smit is someone who can design and create simple, beautiful and easy to understand things. He is an expert at taking designs into original, exciting and new directions.

            </Typography>
          </Grid>
          <Grid item xs={12} sm={6} sx={{padding:"2rem"}}>
            <img
              src={aboutMeImage}
              alt="Portfolio"
              style={{
                maxWidth: "100%",
                height: "auto",
                display: "block",
                marginLeft: "auto",
                marginRight: "auto",
              }}
            />
          </Grid>
        </Grid>
      </Container>
    </div>
  );
};

export default AboutMe;
