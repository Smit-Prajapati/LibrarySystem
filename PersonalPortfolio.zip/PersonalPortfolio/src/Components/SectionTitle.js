import { Typography, Box } from '@mui/material';



const SectionTitle = (props) => {
  return (
    <div style={{marginTop:"7rem"}}>
        <Box position="relative" >
        <Typography
      variant="h1"
      sx={{
        display: { xs: 'none', sm: 'block' },
        fontWeight: '900',
        position: 'absolute',
        top: "-1.3rem",
        left: "0",
        zIndex:"-1",
        color: "transparent",
        WebkitTextStroke: "3px #fff", 
        textStroke: "1px #fff", 
        letterSpacing:"0.5rem",
        opacity:"0.5"
      }}
      className='poppins'
    >
      {props.title}
    </Typography>
      <Typography variant="h2" sx={{ color:"#666", fontWeight: '700', letterSpacing:"1rem", marginLeft:"3rem" }} className='poppins'>{props.title}</Typography>
    </Box>
    </div>
  );
};


export default SectionTitle