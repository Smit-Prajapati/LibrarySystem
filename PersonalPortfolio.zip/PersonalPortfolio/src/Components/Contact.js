import { Card, CardContent, Typography, TextField, Button, Container } from '@mui/material';
import SectionTitle from './SectionTitle';

const Contact = () => {
  return (
    <Container maxWidth="lg">
      <Card sx={{background: "transparent"}} elevation={0}>
      <CardContent>
      <SectionTitle title = {"CONTACT ME"}/>
        <form>
          <TextField label="Name" fullWidth margin="normal" />
          <TextField label="Email" fullWidth margin="normal" />
          <TextField label="Message" fullWidth multiline rows={4} margin="normal" />
          <Button variant="contained" color="primary">
            Submit
          </Button>
        </form>
      </CardContent>
    </Card>
    </Container>
  );
};

export default Contact;
