import { keyframes } from '@mui/system';
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";
import { Button } from "@mui/material";

const hithereAnimation = keyframes`
  0% {
    transform: scale(1, 1);
  }
  15% {
    transform: scale(1.1, 0.9);
  }
  30% {
    transform: scale(0.9, 1.1);
  }
  45% {
    transform: scale(1.1, 0.95);
  }
  60% {
    transform: scale(0.95, 1.05);
  }
  75% {
    transform: scale(1.05, 0.95);
  }
  100% {
    transform: scale(1, 1);
  }
`;

const ResumeButton = ({isAnimated = false}) => {
    return (
      <Button
        variant="contained"
        sx={{
          display: { xs: "none", md: "flex" },
          alignItems: "center",
          gap: "0.5rem",
          color: "white",
          ...(isAnimated && { animation: `${hithereAnimation} 2s cubic-bezier(0.645, 0.045, 0.355, 1) infinite` }),
        }}
      >
        <DownloadRoundedIcon />
        Resume
      </Button>
    );
  };

export default ResumeButton;
