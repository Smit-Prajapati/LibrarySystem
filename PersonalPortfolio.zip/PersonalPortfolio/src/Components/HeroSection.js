
import { Typography, Grid, Container } from "@mui/material";
import heroImage from "../assets/images/hero.png";

import ResumeButton from "./ResumeButton";



const HeroSection = () => {
  return (
    <div style={{ padding: "64px 0 0 0 " }}>
      <Container maxWidth="lg">
      <Grid container sx={{ display: 'flex', gap: '5rem', alignItems: 'center', flexWrap: { xs: 'wrap', sm: 'nowrap' } }}>
          <Grid  sm={5}>
            <img
              src={heroImage}
              alt="Portfolio"
              style={{
                maxWidth: "100%",
                height: "auto",
                display: "block",
                marginLeft: "auto",
                marginRight: "auto",
              }}
            />
          </Grid>
          <Grid item xs={12} sm={7}>
            <Typography
              variant="h3"
              gutterBottom
              sx={{
                color: "#333",
                fontWeight: "600",
                fontFamily: "Poppins, sans-serif",
              }}
              className="poppins"
            >
              Hi, You found me!
            </Typography>
            <Typography
              variant="h4"
              gutterBottom
              sx={{ fontWeight: "500", color: "gray",  mb:4  }}
              className="poppins"
            >
              I am a{" "}
              <Typography
                variant="span"
                component="span"
                color="primary"
                className="poppins"
                
              >
                Full Stack Developer & Designer
              </Typography>{" "}
              from India.
            </Typography>

            <ResumeButton isAnimated={true}/>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
};

export default HeroSection;
