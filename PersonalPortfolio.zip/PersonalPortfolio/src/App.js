
import { ThemeProvider } from '@emotion/react';
import './App.scss';
import Contact from './Components/Contact';
import HeroSection from './Components/HeroSection';
import Navbar from './Components/Navbar';
import { createTheme } from '@mui/material/styles';
import AboutMe from './Components/AboutMe';
import Skills from './Components/Skills';
import Projects from './Components/Projects';

const theme = createTheme({
  palette: {
    primary: {
      main: '#32bdf0', // Your primary color
    },
    text: {
      primary: '#FFFFFF', // Set primary text color to white
    },
    palette: {
      gray: {
        dark1: '#333',   
        dark2: '#666',   
        dark3: '#999',   
      },
    },
  },
});
function App() {
  return (
    <ThemeProvider theme={theme}>
      <div className="App">
      <Navbar/>
      <HeroSection/>
      <AboutMe/>
      <Skills/>
      <Projects />
      <Contact/>
    </div>
    </ThemeProvider>
  );
}

export default App;
