﻿using InsuranceMiniProject.DataAccess.Enum;
using InsuranceMiniProject.DataAccess.Models;
using InsuranceMiniProject.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceMiniProject.UI
{
    public class UserMenu
    {
        private static IPolicyService _policyService;
        public UserMenu(IPolicyService service)
        {
            _policyService = service;
        }

        //public static void Initialize(IPolicyService policyService)
        //{
        //    _policyService = policyService;
        //}

        public static void ShowMenu(User currentUser)
        {
            Console.Clear();
            Console.WriteLine($"Welcome {currentUser.FirstName}");
            Console.WriteLine("╔════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                      USER MENU                         ║");
            Console.WriteLine("╠════════════════════════════════════════════════════════╣");
            Console.WriteLine("║  1   View all available policies                       ║");
            Console.WriteLine("║  2   Buy Policy                                        ║");
            Console.WriteLine("║  3   View your policies                                ║");
            Console.WriteLine("║  4   Claim policy                                      ║");
            Console.WriteLine("║  5   Logout                                            ║");
            Console.WriteLine("║  6   Exit                                              ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════╝");

            Console.WriteLine("\nEnter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    var policies = _policyService.GetAllPolicies();
                    Console.WriteLine("\nAll Policies:");
                    foreach (var policy in policies)
                    {
                        //Console.WriteLine($"ID: {policy.Id}");
                        if (policy.IsActive == true)
                        {
                            Console.WriteLine($"Policy Number: {policy.PolicyNumber}");
                            Console.WriteLine($"Coverage Type: {policy.CoverageType}");
                            Console.WriteLine($"Duration: {policy.Duration} days");
                            Console.WriteLine($"Description: {policy.Description}");
                            Console.WriteLine($"Installment: {policy.Installment}");
                            Console.WriteLine($"Premium Amount: {policy.PremiumAmount}");
                            //Console.WriteLine($"Is Active: {policy.IsActive ?? false}");
                            Console.WriteLine();

                        }
                    }
                            Console.WriteLine("Press any key to continue");
                            Console.ReadKey();
                            ShowMenu(currentUser);
                    break;
                case 2:
                    Console.WriteLine("manage managers");
                    break;
                case 3:
                   

                    break;
                case 4:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid Choice");
                    break;

            }
        }
    }
}
